# -*- coding: utf-8 -*-
"""
Created on Tue Jan 31 11:54:18 2023

@author: USER
"""

import termcolor
from logic import *

Plum = Symbol("Plum")
Green = Symbol("Green")
Mustard = Symbol("Mustard")
Peacock = Symbol("Peacock")
characters = [Plum, Green, Mustard, Peacock]

estudio = Symbol("estudio")
pasillo = Symbol("pasillo")
sala = Symbol("sala")
juegos = Symbol("juegos")
rooms = [estudio, pasillo, sala, juegos]

revolver = Symbol("revolver")
hacha = Symbol("hacha")
candelabro = Symbol("candelabro")
herramienta = Symbol("herramienta")
weapons = [revolver, hacha, candelabro, herramienta]

symbols = characters + rooms + weapons


def check_knowledge(knowledge):
    for symbol in symbols:
        if model_check(knowledge, symbol):
            termcolor.cprint(f"{symbol}: SI", "green")
        elif not model_check(knowledge, Not(symbol)):
            print(f"{symbol}: TAL VEZ")


# There must be a person, room, and weapon.
knowledge = And(
    Or(Plum, Green, Mustard, Peacock),
    Or(estudio, pasillo, sala, juegos),
    Or(revolver, hacha, candelabro, herramienta)
)

# Constraints to ensure there is only one killer option
knowledge.add(Or(
    And(Plum, Not(Green), Not(Mustard), Not(Peacock)),
    And(Green, Not(Plum), Not(Mustard), Not(Peacock)),
    And(Mustard, Not(Plum), Not(Green), Not(Peacock)),
    And(Peacock, Not(Plum), Not(Green), Not(Mustard))
))

# Constraints to ensure there is only one option for one room
knowledge.add(Or(
    And(estudio, Not(pasillo), Not(sala), Not(juegos)),
    And(pasillo, Not(estudio), Not(sala), Not(juegos)),
    And(sala, Not(estudio), Not(pasillo), Not(juegos)),
    And(juegos, Not(estudio), Not(pasillo), Not(sala))
))

# Constraints to ensure there is only one option for tool
knowledge.add(Or(
    And(revolver, Not(hacha), Not(candelabro), Not(herramienta)),
    And(hacha, Not(revolver), Not(candelabro), Not(herramienta)),
    And(candelabro, Not(revolver), Not(hacha), Not(herramienta)),
    And(herramienta, Not(revolver), Not(hacha), Not(candelabro))
))


print("Base de conocimiento: ", knowledge.formula())
print("¿Qué sé?")
check_knowledge(knowledge)

# Initial cards
knowledge.add(And(
    Not(Green), Not(pasillo), Not(candelabro)
))
print("Base de conocimiento: ", knowledge.formula())
print("¿Qué sé?")
check_knowledge(knowledge)

# Unknown card
knowledge.add(Or(
    Not(Peacock), Not(estudio), Not(revolver)
))
print("Base de conocimiento: ", knowledge.formula())
print("¿Qué sé?")
check_knowledge(knowledge)

# Known cards
knowledge.add(Not(Mustard))
knowledge.add(Not(herramienta))
print("Base de conocimiento: ", knowledge.formula())
print("¿Qué sé?")
check_knowledge(knowledge)

# Unknown card
knowledge.add(Or(
    Not(Plum), Not(estudio), Not(hacha)
))
print("Base de conocimiento: ", knowledge.formula())
print("¿Qué sé?")
check_knowledge(knowledge)

# Unknown card
knowledge.add(Or(
    Not(Peacock), Not(juegos), Not(revolver)
))
print("Base de conocimiento: ", knowledge.formula())
print("¿Qué sé?")
check_knowledge(knowledge)

# Unknown card
knowledge.add(Not(hacha))
print("Base de conocimiento: ", knowledge.formula())
print("¿Qué sé?")
check_knowledge(knowledge)

# Unknown card
knowledge.add(juegos)
print("Base de conocimiento: ", knowledge.formula())
print("¿Qué sé?")
check_knowledge(knowledge)
